#include<iostream>
using namespace std;
class Shape {
public: void setWidth(int w)
 {
width = w;
    }
void setHeight(int h)
{
 height = h;
}
protected:
int width;
int height;
  };
 class triangle {
 public: int getArea(int area)
    {
  return area;
   } };
class Rectangle: public Shape, public triangle
{
    public: int getArea()
    {
         return (width * height);
          } };
int main(void)
{
    Rectangle Rect;
    Rect.setWidth(5);
    Rect.setHeight(7);
      int area = Rect.getArea();
      int area = tri.getArea();
cout<<"Total area:"<< area <<endl;
  return 0; }
