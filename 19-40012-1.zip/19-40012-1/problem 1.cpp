#include<iostream>
using namespace std;
class ITEMS
{
int itemCode;
float itemPrice;

public:
 int setitemCode(int Code);
 float setitemPrice(float price);
 void showitem();

};

int ITEMS :: setItemCode(int icode)
{
    itemCode = iCode;
}
float ITEMS :: setItemPrice(float iprice)
{
    itemPrice = iprice;
}
void ITEMS :: showitem()
{
    cout<<"\nThe code of the item is"<<itemCode<<"\nThe price of the item is"<<itemPrice;
}

 int main()
{
 ITEMS object;
 int c;
 float p;
 cout<<"Enter the code of the item";
 cin>>c;
 cout<<"\nEnter the price of the item";
 cin>>p;
object.setItemCode(c);
object.setItemPrice(p);
object.showItem();
}
