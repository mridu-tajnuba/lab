#include<iostream>
using namespace std;
class Building{
public: void setWidth(int w)
{
width= r;
}
void setHeight(int h)
{
height = h;
 }
  protected:
int width;
int height;
};
class house {
public:
int getRoom(int area)
 {
return area;
 } };
class office: public building, public house
{
public:
    int getRoom()
    {
return
(width * height);
 } };
int main(void)
{
Rectangle Rect;
 Rect.setWidth(5);
 Rect.setHeight(7);
 int area = Rect.getArea();
cout<<"Total area:"<< area <<endl;
 cout<<"Total house� << office.getRoom(area);
  return 0;
   }


};
